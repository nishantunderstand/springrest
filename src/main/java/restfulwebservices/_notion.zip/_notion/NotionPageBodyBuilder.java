package restfulwebservices._notion;

public final class NotionPageBodyBuilder {

    private NotionPageBodyBuilder() {
        // utility class
    }

    public static String buildBody() {

        return """
        "children": [
          {
            "object": "block",
            "type": "heading_2",
            "heading_2": {
              "rich_text": [
                { "type": "text", "text": { "content": "Body" } }
              ]
            }
          },
          {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
              "rich_text": [
                {
                  "type": "text",
                  "text": { "content": "This page is created for testing purposes." }
                }
              ]
            }
          },
          {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
              "rich_text": [
                {
                  "type": "text",
                  "text": {
                    "content": "Priority is set to 1 and the current status is New."
                  }
                }
              ]
            }
          },
          {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
              "rich_text": [
                {
                  "type": "text",
                  "text": {
                    "content": "Reference URL: https://www.google.com"
                  }
                }
              ]
            }
          }
        ]
        """;
    }
}
