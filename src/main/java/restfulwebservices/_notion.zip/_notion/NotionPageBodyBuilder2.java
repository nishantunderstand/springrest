package restfulwebservices._notion;

public final class NotionPageBodyBuilder2 {

    private NotionPageBodyBuilder2() {
    }

    public static String buildBody() {

        return """
        "children": [

          {
            "type": "heading_2",
            "heading_2": {
              "rich_text": [{ "type": "text", "text": { "content": "Dependency & Dependency Injection" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "What is dependency" } }]
            }
          },

          {
            "type": "image",
            "image": {
              "type": "external",
              "external": {
                "url": "https://s3-us-west-2.amazonaws.com/secure.notion-static.com/389504e9-e05d-4c73-a71b-3cbc8f7d538d/1_0P-1JhnUaZeobDUAajIbhA.jpeg"
              }
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "What is Dependency Injection" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Why we need Dependency Injection (DI)" } }]
            }
          },

          {
            "type": "paragraph",
            "paragraph": {
              "rich_text": [{
                "type": "text",
                "text": {
                  "content": "As Java applications are quite large, DI helps make classes independent, reduces object creation complexity, and delegates responsibility to the IoC container."
                }
              }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Advantages of Dependency Injection" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Disadvantages of Dependency Injection" } }]
            }
          },

          {
            "type": "heading_3",
            "heading_3": {
              "rich_text": [{ "type": "text", "text": { "content": "Does DI support data types?" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Primitive Data Types – Yes" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Non-Primitive Data Types – Yes" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "String Data Type – Yes" } }]
            }
          },

          {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Collection Data Types – Yes" } }]
            }
          },

          {
            "type": "heading_3",
            "heading_3": {
              "rich_text": [{ "type": "text", "text": { "content": "Types of Dependency Injection" } }]
            }
          },

          {
            "type": "numbered_list_item",
            "numbered_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Constructor Based Injection" } }]
            }
          },

          {
            "type": "numbered_list_item",
            "numbered_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Setter Based Injection" } }]
            }
          },

          {
            "type": "numbered_list_item",
            "numbered_list_item": {
              "rich_text": [{ "type": "text", "text": { "content": "Field Based Injection" } }]
            }
          },

          {
            "type": "paragraph",
            "paragraph": {
              "rich_text": [{
                "type": "text",
                "text": {
                  "content": "Java Brains Explanation: https://www.youtube.com/watch?v=GB8k2-Egfv0",
                  "link": { "url": "https://www.youtube.com/watch?v=GB8k2-Egfv0" }
                }
              }]
            }
          },

          {
            "type": "paragraph",
            "paragraph": {
              "rich_text": [{
                "type": "text",
                "text": {
                  "content": "Main goal of Spring is to decouple dependent objects. Dependency Injection separates dependency creation and injects them when needed."
                }
              }]
            }
          }

        ]
        """;
    }
}
