package restfulwebservices._notion;

public final class NotionPageBodyBuilder3 {

    private NotionPageBodyBuilder3() {
    }

    public static String buildBody() {

        return """
        "children": [

          {
            "type": "heading_2",
            "heading_2": {
              "rich_text": [{ "type": "text", "text": { "content": "Dependency & Dependency Injection" } }]
            }
          },

          {
            "type": "heading_3",
            "heading_3": {
              "rich_text": [{ "type": "text", "text": { "content": "Java Code Example" } }]
            }
          },

          {
            "type": "code",
            "code": {
              "language": "java",
              "rich_text": [
                {
                  "type": "text",
                  "text": {
                    "content": "int cnt = 0;\\n" +
                               "ListNode temp = head;\\n" +
                               "while (temp != null) {\\n" +
                               "    if (temp.val == key) cnt++;\\n" +
                               "    temp = temp.next;\\n" +
                               "}\\n\\n" +
                               "ListNode dummy = new ListNode(-1);\\n" +
                               "dummy.next = head;\\n\\n" +
                               "ListNode prev = dummy;\\n" +
                               "ListNode curr = head;\\n\\n" +
                               "while (curr != null) {\\n" +
                               "    if (curr.val == key) {\\n" +
                               "        cnt--;\\n" +
                               "        if (cnt == 0) {\\n" +
                               "            prev.next = curr.next;   // correct deletion\\n" +
                               "            break;\\n" +
                               "        }\\n" +
                               "    }\\n" +
                               "    prev = curr;\\n" +
                               "    curr = curr.next;\\n" +
                               "}\\n\\n" +
                               "return dummy.next;"
                  }
                }
              ]
            }
          }

        ]
        """;
    }
}
